
#ifndef _TESTBUG_H
#define _TESTBUG_H

void EnableDiv0Bug(void);

int CreateBug(int b, int n);

#endif

