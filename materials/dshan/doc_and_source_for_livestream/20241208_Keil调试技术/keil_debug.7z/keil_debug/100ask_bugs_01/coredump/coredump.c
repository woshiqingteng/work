#include "mystring.h"
#include "coredump.h"

extern int * Image$$ER_IROM1$$Base;
extern int * Image$$ER_IROM1$$Length;
extern int * Load$$ER_IROM1$$Base;
extern int * Image$$RW_IRAM1$$Base;
extern int * Image$$RW_IRAM1$$Length;
extern int * Load$$RW_IRAM1$$Base;
extern int * Image$$RW_IRAM1$$ZI$$Base;
extern int * Image$$RW_IRAM1$$ZI$$Length;	

#if 0
/* text relocate */
memcpy(&Image$$ER_IROM1$$Base, &Load$$ER_IROM1$$Base, &Image$$ER_IROM1$$Length);

/* data relocate */
memcpy(&Image$$RW_IRAM1$$Base, &Load$$RW_IRAM1$$Base, &Image$$RW_IRAM1$$Length);

/* bss clear */
memset(&Image$$RW_IRAM1$$ZI$$Base, 0, &Image$$RW_IRAM1$$ZI$$Length);
#endif

static void DumpRegisters(pregs sp, char *thread)
{
	myputs("Registers@");
	myputs(thread);
	myputs("\n");
	myput_s_hex("R0: ", sp->r0); myputs("\n");
	myput_s_hex("R1: ", sp->r1); myputs("\n");
	myput_s_hex("R2: ", sp->r2); myputs("\n");
	myput_s_hex("R3: ", sp->r3); myputs("\n");
	myput_s_hex("R4: ", sp->r4); myputs("\n");
	myput_s_hex("R5: ", sp->r5); myputs("\n");
	myput_s_hex("R6: ", sp->r6); myputs("\n");
	myput_s_hex("R7: ", sp->r7); myputs("\n");
	myput_s_hex("R8: ", sp->r8); myputs("\n");
	myput_s_hex("R9: ", sp->r9); myputs("\n");
	myput_s_hex("R10: ", sp->r10); myputs("\n");
	myput_s_hex("R11: ", sp->r11); myputs("\n");
	myput_s_hex("R12: ", sp->r12); myputs("\n");
	myput_s_hex("R13(SP): ", (uint32_t)sp + sizeof(*sp)); myputs("\n");
	myput_s_hex("R14(LR): ", sp->lr); myputs("\n");
	myput_s_hex("R15(PC): ", sp->pc); myputs("\n");
	myput_s_hex("xPSR: ", sp->xpsr); myputs("\n");
}

static void DumpMem(uint32_t addr, uint32_t len)
{
	uint32_t *paddr;
	uint32_t i;
	
	paddr = (uint32_t *)addr;
	myput_s_hex("mem@", addr);
	myput_s_hex(",", len);
	myputs("\n");
	
	for (i = 0; i < len;)
	{
		myputhex(*paddr);
		paddr++;

		i+= 4;
		if (i % 16 == 0)
			myputs("\n");
		else
			myputs(" ");
	}
	myputs("\n");
}

void DumpCore(pregs sp)
{
	/* 打印寄存器 */
	DumpRegisters(sp, "main_thread");
	
	/* 打印数据段 */
	myputs("Data segment:\n");
	DumpMem((uint32_t)&Image$$RW_IRAM1$$Base, (uint32_t)&Image$$RW_IRAM1$$Length);

	/* 打印ZI段 */
	myputs("ZI segment:\n");
	DumpMem((uint32_t)&Image$$RW_IRAM1$$ZI$$Base, (uint32_t)&Image$$RW_IRAM1$$ZI$$Length);

	/* 打印栈 */
	myputs("Stack segment:\n");
	DumpMem((uint32_t)sp + sizeof(*sp), 1024);
}

