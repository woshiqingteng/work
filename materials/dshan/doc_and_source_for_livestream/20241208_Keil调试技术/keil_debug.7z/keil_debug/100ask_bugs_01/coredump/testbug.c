#include "mystring.h"
#include "myuart.h"

void EnableDiv0Bug(void)
{
	/* 100ask add */
	/* 使能除0错误
	 * CCR(0xE000ED14)的bit4(DIV_0_TRP)设置为1
	 */
	volatile int *CCR = (volatile int *)0xE000ED14;
	*CCR |= (1<<4);

}

volatile int g_val = 0x12345678;

int CreateBug(int b, int n)
{
    volatile char buf[8];    
    int (*volatile f)(int, int);
    
    buf[0] = buf[7] = 0xaa;
    f(1,2);
	return b / n;
}

void D(int n, int m)
{
	CreateBug(n, m);
}
void C(int n, int m)
{
	D(n, m);
}

void B(int n, int m)
{
	C(n, m);
}

void AA(void)
{
    volatile int a = 1;
}

void A(int n, int m)
{
    volatile int tmp;
    
    tmp = g_val*n;
    
    AA();
    //led_blink();
	B(tmp, m);
    
}


int add(int a, int b)
{
    volatile int sum;
    sum = a + b;
    
    myput_s_hex("sum is ", sum);
    
    return sum;
}


void buf_overflow(int n, char val)
{
    volatile char buf[5];
    volatile int a = 0x55;
    buf[0] = 0x5a;
    a++;
    buf[n] = val;
    myput_s_hex("buf[0] = ", buf[0]);
    myputs("\n");
    myput_s_hex("a is ", a);
    myputs("\n");
}
    

