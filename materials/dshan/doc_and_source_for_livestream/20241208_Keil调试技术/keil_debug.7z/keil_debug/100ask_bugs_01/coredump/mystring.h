
#ifndef _MYSTRING_H
#define _MYSTRING_H
int myputs(const char *s);
void myputhex(unsigned int val);
void myput_s_hex(const char *s, unsigned int val);
#endif /* _MYSTRING_H */

