
#ifndef _MYUART_H
#define _MYUART_H
int mygetchar(void);
int myputchar(char c);

#endif
