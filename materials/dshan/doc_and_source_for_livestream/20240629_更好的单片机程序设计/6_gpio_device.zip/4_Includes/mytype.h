#ifndef __MYTYPE_H
#define __MYTYPE_H

#define NULLDEV     (0)

#endif /* __MYTYPE_H */
