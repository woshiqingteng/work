#ifndef __CONFIG_H
#define __CONFIG_H

/* 管理设备对象是否使用 */
#define USE_GPIO_DEVICE     (1)
#define USE_UART_DEVICE     (0)

#endif /* __CONFIG_H */
