#ifndef __DEVICES_H
#define __DEVICES_H

#include "config.h"

#if USE_GPIO_DEVICE
    #include "dev_gpio.h"
    #define USE_GPIO_DRIVER
#endif

#if USE_UART_DEVICE
    #define USE_UART_DRIVER
#endif

#endif /* __DEVICES_H */
