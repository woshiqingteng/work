#include "dev_gpio.h"
#include "./drv_config/gpio_config.h"
#include "errno.h"
#include "stm32f4xx_hal.h"

static int KeyDrvInit(struct GPIODev *ptdev);
static int KeyDrvRead(struct GPIODev *ptdev);

static GPIODevice gKeyDevices[] = {
    K1,
    K2, 
    K3, 
    K4
};

void KeyDevicesCreate(void)
{
    unsigned int num = sizeof(gKeyDevices) / sizeof(struct GPIODev);
    for(unsigned int i = 0; i<num; i++)
        IODeviceInsert(&gKeyDevices[i]);
}

static int KeyDrvInit(struct GPIODev *ptdev)
{
    if(NULL == ptdev)   return -EINVAL;
    
    return ESUCCESS;
}

static int KeyDrvRead(struct GPIODev *ptdev)
{
    if(NULL == ptdev)   return -EINVAL;
    int status = HAL_GPIO_ReadPin(ptdev->port, ptdev->pin);
    
    return status;
}