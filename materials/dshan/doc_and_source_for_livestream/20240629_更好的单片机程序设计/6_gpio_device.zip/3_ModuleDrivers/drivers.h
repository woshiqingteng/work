#ifndef __DRIVERS_H
#define __DRIVERS_H

#include "devices.h"

#ifdef USE_GPIO_DRIVER
    #include "drv_gpio.h"
#endif /* USE_GPIO_DRIVER */

#ifdef USE_UART_DRIVER
    #include "drv_uart.h"
#endif /* USE_UART_DEVICE */

#endif /* __DRIVERS_H */
