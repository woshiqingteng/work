#ifndef __DRV_LED_H
#define __DRV_LED_H

void LedDevicesCreate(void);

#endif /* __DRV_LED_H */
