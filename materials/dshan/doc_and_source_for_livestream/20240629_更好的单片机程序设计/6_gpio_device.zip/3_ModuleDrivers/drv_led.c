#include "dev_gpio.h"
#include "./drv_config/gpio_config.h"
#include "errno.h"
#include "stm32f4xx_hal.h"

static int LedDrvInit(struct GPIODev *ptdev);
static int LedDrvWrite(struct GPIODev *ptdev, unsigned char status);
static int LedDrvRead(struct GPIODev *ptdev);

static GPIODevice gLedDevices[] = {
    D1,
    D2, 
    D3, 
    D4
};

void LedDevicesCreate(void)
{
    unsigned int num = sizeof(gLedDevices) / sizeof(struct GPIODev);
    for(unsigned int i = 0; i<num; i++)
        IODeviceInsert(&gLedDevices[i]);
}

static int LedDrvInit(struct GPIODev *ptdev)
{
    if(NULL == ptdev)   return -EINVAL;
    
    return ESUCCESS;
}

static int LedDrvWrite(struct GPIODev *ptdev, unsigned char status)
{
    if(NULL == ptdev)   return -EINVAL;
    if(status !=0 && status != 1)   return -EINVAL;
    HAL_GPIO_WritePin(ptdev->port, ptdev->pin, status);
    
    return ESUCCESS;
}

static int LedDrvRead(struct GPIODev *ptdev)
{
    if(NULL == ptdev)   return -EINVAL;
    int status = HAL_GPIO_ReadPin(ptdev->port, ptdev->pin);
    
    return status;
}

