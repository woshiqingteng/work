#ifndef __DRV_KEY_H
#define __DRV_KEY_H

void KeyDevicesCreate(void);

#endif /* __DRV_KEY_H */