#include "dev_gpio.h"
#include "./drv_config/gpio_config.h"
#include "errno.h"
#include "stm32f4xx_hal.h"

static int GPIODrvInit(struct GPIODev *ptdev);
static int GPIODrvWrite(struct GPIODev *ptdev, unsigned char status);
static int GPIODrvRead(struct GPIODev *ptdev);

static GPIODevice gGPIODevices[] = {
    D1,
    D2, 
    D3, 
    D4,
    K1,
    K2, 
    K3, 
    K4,
};

void GPIODevicesCreate(void)
{
    unsigned int num = sizeof(gGPIODevices) / sizeof(struct GPIODev);
    for(unsigned int i = 0; i<num; i++)
        IODeviceInsert(&gGPIODevices[i]);
}

static int GPIODrvInit(struct GPIODev *ptdev)
{
    if(NULL == ptdev)   return -EINVAL;
    
    return ESUCCESS;
}

static int GPIODrvWrite(struct GPIODev *ptdev, unsigned char status)
{
    if(NULL == ptdev)   return -EINVAL;
    if(status !=0 && status != 1)   return -EINVAL;
    HAL_GPIO_WritePin(ptdev->port, ptdev->pin, status);
    
    return ESUCCESS;
}

static int GPIODrvRead(struct GPIODev *ptdev)
{
    if(NULL == ptdev)   return -EINVAL;
    int status = HAL_GPIO_ReadPin(ptdev->port, ptdev->pin);
    
    return status;
}

