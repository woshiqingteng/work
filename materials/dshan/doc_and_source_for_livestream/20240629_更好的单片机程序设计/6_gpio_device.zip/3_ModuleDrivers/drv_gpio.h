#ifndef __DRV_GPIO_H
#define __DRV_GPIO_H

void GPIODevicesCreate(void);

#endif /* __DRV_GPIO_H */
