/*
 * Project: N|Watch
 * Author: Zak Kemble, contact@zakkemble.co.uk
 * Copyright: (C) 2013 by Zak Kemble
 * License: GNU GPL v3 (see License.txt)
 * Web: http://blog.zakkemble.co.uk/diy-digital-wristwatch/
 */

#ifndef GAME1_H_
#define GAME1_H_

#if COMPILE_GAME1

#define GAME1_NAME STR_GAME1

void game1_start(void);

#endif

#endif /* GAME1_H_ */
