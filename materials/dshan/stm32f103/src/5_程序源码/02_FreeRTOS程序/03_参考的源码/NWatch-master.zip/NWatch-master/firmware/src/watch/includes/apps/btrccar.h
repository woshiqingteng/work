/*
 * Project: N|Watch
 * Author: Zak Kemble, contact@zakkemble.co.uk
 * Copyright: (C) 2014 by Zak Kemble
 * License: GNU GPL v3 (see License.txt)
 * Web: http://blog.zakkemble.co.uk/diy-digital-wristwatch/
 */

#ifndef BTRCCAR_H_
#define BTRCCAR_H_

#if COMPILE_BTRCCAR

void btrccar_open(void);

#endif

#endif /* BTRCCAR_H_ */
