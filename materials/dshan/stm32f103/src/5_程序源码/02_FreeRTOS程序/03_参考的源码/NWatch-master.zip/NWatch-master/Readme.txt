N|Watch - DIY Digital Wristwatch
http://blog.zakkemble.co.uk/diy-digital-wristwatch/

The firmware .hex and .eep files are compiled for ATmega328P

Fuses for ATmega328/328P
Internal RC 8MHz 6 CK/14CK + 65ms startup
Bootloader enabled, 256 words (512 bytes)
Serial program (SPI) enabled
Brown-out at 1.8V
High:		0xDE
Low:		0xE2
Extended:	0x06

./utils/bitmapConverter.exe
Utility to convert images (in ./imgs/) to pixel byte array

Font used for the large numbers on the main time display is AgencyFB Bold Wide available at http://www.fontsner.com/font/AgencyFBBoldWide-37966.html
My productions are published under GNU GPL v3 (see License.txt).

--------

Zak Kemble
contact@zakkemble.co.uk